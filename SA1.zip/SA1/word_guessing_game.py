'''Start by creating a new Python file and saving it as "word_guessing_game.py" or you can just use the filename above.

Open the "words.txt" file, which contains a list of words that will be used in the game. Each word should be on a
separate line in the file.

Create a function to randomly select a word from the "words.txt" file.

Create a function to display the word to the player. This function should replace all letters in the word with
underscores, except for letters that have already been guessed.

Create a function to get the player's guess. This
function should ask the player to enter a letter and validate the input to make sure it is a single letter.

Create a main function to run the game. The main function should use the previously defined functions to select a word,
display it to the player, and prompt the player for guesses until the word is guessed or the player runs out of
guesses. Finally, call the main function to run the game. '''
from random import choice
def random_word_function(choices):
    return choice(words)

def underscores_function(word):
    return ' '.join('_' for let in random_word)


def underscore_function(random_word, letters_guessed, guesses, guess_let):
    # while guesses > 0 and '_' in update:
    # guess_let = input("Guess a letter: ").lower()[0]
    letters_guessed.append(guess_let)
    # validate = ' '.join('_' if guess_let != letter else guess_let for letter in random_word)
    update = ' '.join(letter if letter in letters_guessed else '_' for letter in random_word)
    print(update)
    if guess_let not in random_word:
        guesses -= 1
        # print(f'Incorrect. '' guesses remaining.')
        # print('Correct!')
    return [letters_guessed, update, guesses]
        
    


with open('words.txt', 'r') as file:
    contents = file.read()
    words = contents.split()
    random_word = random_word_function(words)
    print(random_word)
    underscores = ' '.join('_' for let in random_word)
    initial_guesses = 8
    guesses = initial_guesses
    letters_guessed = []
    guess_let = ''
    while True:
        data = underscore_function(random_word=random_word, letters_guessed=letters_guessed, guesses=guesses, guess_let=guess_let)
        guess_let = input("Guess a letter: ").lower()[0]
        letters_guessed = data[0]
        update = data[1]
        print(data)
        if '_' not in update:
            print(f'Congratulations! You have guessed all the letters of the word "{random_word}"')
            break
        elif guesses < initial_guesses:
            if data[2] < guesses:
                guesses = data[2]
                print(f'Incorrect. {guesses} guesses remaining.')
            else:
                print('Correct!')
        elif guesses==0:
            print(f'Sorry, you lose. The word was {random_word}')
            break